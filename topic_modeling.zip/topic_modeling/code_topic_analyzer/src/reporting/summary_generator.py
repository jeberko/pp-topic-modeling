from dataclasses import dataclass
from typing import Dict, List, Any
from pathlib import Path
import numpy as np
from sklearn.decomposition import LatentDirichletAllocation

@dataclass
class ReportingConfig:
    min_topic_strength: float = 0.3
    top_words_per_topic: int = 10

class SummaryReporter:
    def __init__(self, config: ReportingConfig = None):
        self.config = config or ReportingConfig()

    def generate_summary(
        self,
        model: LatentDirichletAllocation,
        feature_names: np.ndarray,
        doc_topics: np.ndarray,
        files: List[str],
        structures: Dict,
        term_clusters: Dict
    ) -> str:
        """Generate comprehensive analysis summary."""
        topic_dist = self._get_topic_distributions(model, feature_names)
        doc_assignments = self._get_document_assignments(doc_topics, files)
        
        summary = self._create_summary_text(
            topic_dist,
            doc_assignments,
            structures,
            term_clusters
        )
        
        return summary

    def _get_topic_distributions(
        self,
        model: LatentDirichletAllocation,
        feature_names: np.ndarray
    ) -> List[List[str]]:
        """Get topic-word distributions."""
        topic_word_dist = []
        for topic_idx, topic in enumerate(model.components_):
            top_words_idx = topic.argsort()[:-self.config.get('top_words_per_topic')-1:-1]
            top_words = feature_names[top_words_idx]
            top_probs = topic[top_words_idx]
            
            term_pairs = []
            for word, prob in zip(top_words, top_probs):
                if prob > 0.1:
                    term_pairs.append(f"{word} ({prob:.2f})")
            
            topic_word_dist.append(term_pairs)
        
        return topic_word_dist

    def _get_document_assignments(
        self,
        doc_topics: np.ndarray,
        files: List[str]
    ) -> List[Dict[str, Any]]:
        """Get document-topic assignments."""
        assignments = []
        for doc_idx, (doc_topic_dist, file_path) in enumerate(zip(doc_topics, files)):
            primary_topic = doc_topic_dist.argmax()
            strength = doc_topic_dist[primary_topic]
            if strength > self.config.get('min_topic_strength'):
                assignments.append({
                    'file': file_path,
                    'topic': primary_topic,
                    'strength': strength
                })
        return assignments

    def _create_summary_text(
        self,
        topic_dist: List[List[str]],
        doc_assignments: List[Dict[str, Any]],
        structures: Dict,
        term_clusters: Dict
    ) -> str:
        """Create formatted summary text."""
        summary = self.config.get('base_prompt', '') + """
        
        Code Analysis Summary:
        
        Topic Word Distributions:
        """ + "-" * 10 + "\n"
        
        summary += "\n".join([
            f"Topic {i+1}: {', '.join(terms)}"
            for i, terms in enumerate(topic_dist)
        ])
        
        summary += "\n\nDocument Assignments:\n" + "-" * 40 + "\n"
        summary += "\n".join([
            f"{d['file']} → Topic {d['topic']+1} ({d['strength']:.2f})"
            for d in doc_assignments
        ])
        
        summary += "\n\nCode Structure Analysis:\n" + "-" * 40 + "\n"
        for file_path, structure in structures.items():
            summary += f"\nFile: {Path(file_path).name}\n"
            for category, items in structure.items():
                if items:
                    summary += f"{category.capitalize()}: {', '.join(items)}\n"
        
        summary += "\nTerm Clusters:\n" + "-" * 40 + "\n"
        for cluster_id, terms in term_clusters.items():
            summary += f"\nCluster {cluster_id + 1}: {', '.join(terms)}"
        
        return summary

    def save_report(self, summary: str, output_path: str) -> None:
        """Save the summary to a file."""
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(summary)
            print(f"\nReport has been written to '{output_path}'")
        except Exception as e:
            print(f"Error writing report: {e}")