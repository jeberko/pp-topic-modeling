
import argparse
from pathlib import Path
import sys
import logging
from analyzer import CodeAnalyzer
from utils.logger import LoggerSetup

""" 
    python main.py /path/to/repository
    With custom config:
    python main.py /path/to/repository --config /path/to/config.yaml
    With custom output:
    python main.py /path/to/repository --output analysis_result.txt
    With verbose logging:
    python main.py /path/to/repository -v
    Get help:
    python main.py --help
"""

#!/usr/bin/env python3

def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='Analyze code repository using topic modeling.',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    parser.add_argument(
        'repo_path',
        type=str,
        help='Path to the repository to analyze'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='config/config.yaml',
        help='Path to configuration file'
    )
    
    parser.add_argument(
        '--output',
        type=str,
        help='Output file path (overrides config setting)'
    )
    
    parser.add_argument(
        '--verbose',
        '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    
    return parser.parse_args()

def main():
    # Parse arguments
    args = parse_arguments()
    
    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = LoggerSetup.setup_logger(
        'code_analyzer',
        Path('logs/analyzer.log'),
        level=log_level
    )
    
    try:
        # Validate repository path
        repo_path = Path(args.repo_path)
        if not repo_path.exists():
            logger.error(f"Repository path not found: {repo_path}")
            sys.exit(1)
        
        # Validate config path
        config_path = Path(args.config)
        if not config_path.exists():
            logger.error(f"Configuration file not found: {config_path}")
            sys.exit(1)
            
        # Initialize analyzer
        analyzer = CodeAnalyzer(config_path)
        
        # Override output path if specified
        if args.output:
            analyzer.config.paths['output_file'] = args.output
        
        # Run analysis
        logger.info(f"Analyzing repository: {repo_path}")
        analyzer.analyze_repository(repo_path)
        logger.info("Analysis completed successfully")

    except Exception as e:
        logger.error(f"Analysis failed: {str(e)}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()