from pathlib import Path
from typing import List, Set
import os

class FileHandler:
    
    def __init__(self):
        # Default extensions can be overridden by config
        self.file_extensions = {'.cpp', '.hpp', '.h', '.cc', '.py'}
        self.ignore_patterns = {
            'node_modules',
            'venv',
            '.git',
            '__pycache__',
            'build',
            'dist'
        }

    def set_extensions(self, extensions: Set[str]) -> None:
        self.file_extensions = extensions

    def get_source_files(self, repo_path: Path) -> List[Path]:
        """Get all source files in the repository."""
        return [
            path for path in repo_path.rglob('*')
            if path.suffix.lower() in self.file_extensions
            and path.is_file()
            and not self._is_ignored(path)
        ]

    def _is_ignored(self, path: Path) -> bool:
        """Check if path should be ignored."""
        return any(part in self.ignore_patterns for part in path.parts)

    @staticmethod
    def ensure_directory(path: Path) -> None:
        """Ensure directory exists."""
        path.parent.mkdir(parents=True, exist_ok=True)