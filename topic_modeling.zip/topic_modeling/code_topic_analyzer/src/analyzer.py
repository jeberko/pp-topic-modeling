from pathlib import Path
import yaml
from typing import Dict, Any, Set
from dataclasses import dataclass

from utils.file_handler import FileHandler
from vectorizer.code_vectorizer import CodeVectorizer
from analysis.topic_modeler import TopicModeler
from analysis.clustering import TermClusterer
from reporting.summary_generator import SummaryReporter

@dataclass
class AnalyzerConfig:
    vectorizer: Dict[str, Any]
    topic_modeling: Dict[str, Any]
    clustering: Dict[str, Any]
    paths: Dict[str, Any]
    semantic_groups: Dict[str, Any]
    file_extensions: Set[str]
    reporting: Dict[str, Any]

class CodeAnalyzer:
    def __init__(self, config_path: Path):
        self.config = self._load_config(config_path)
        
        # Initialize components with config
        self.file_handler = FileHandler()
        self.file_handler.set_extensions(self.config.file_extensions)
        self.vectorizer = CodeVectorizer(self.config.vectorizer)
        self.topic_modeler = TopicModeler(self.config.topic_modeling)
        self.clusterer = TermClusterer(self.config.clustering)
        self.reporter = SummaryReporter(self.config.reporting)

    @staticmethod
    def _load_config(config_path: Path) -> AnalyzerConfig:
        with open(config_path) as f:
            config_dict = yaml.safe_load(f)
        return AnalyzerConfig(**config_dict)

    def analyze_repository(self, repo_path: Path) -> None:
        # Get source files
        source_files = self.file_handler.get_source_files(repo_path)
        
        # Process repository
        doc_term_matrix, terms, files, structures = self.vectorizer.process_repository(
            source_files
        )
        
        # Create topic model
        topic_model, doc_topics = self.topic_modeler.create_model(doc_term_matrix)
        
        # Cluster terms
        term_clusters = self.clusterer.cluster_terms(doc_term_matrix, terms)
        
        # Generate and save report
        summary = self.reporter.generate_summary(
            topic_model, terms, doc_topics, files, 
            structures, term_clusters
        )
        self.reporter.save_report(summary, self.config.paths['output_file'])