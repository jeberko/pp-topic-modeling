from dataclasses import dataclass
from typing import Dict, Set, Tuple, List
import numpy as np
from pathlib import Path
from scipy.sparse import csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from .code_processor import CodeProcessor

@dataclass
class VectorizerConfig:
    max_df: float = 1.0
    min_df: float = 1.0
    file_extensions: Set[str] = frozenset({".cpp", ".hpp", ".h", ".cc", ".c", ".py", ".cxx", ".c++", ".hxx", ".h++",".tpp", ".txx", ".ipp", ".cu",".inl", ".cmake", ".proto"})
    max_features: int = 1000

class CodeVectorizer:
    def __init__(self, config: VectorizerConfig):
        self.config = config
        self.processor = CodeProcessor()
        self.vectorizer = self._initialize_vectorizer()

    def _initialize_vectorizer(self) -> TfidfVectorizer:
        print(self.config)
        return TfidfVectorizer(
            max_df=self.config.get('max_df', 1.0),
            min_df=self.config.get('min_df', 1.0),
            stop_words='english',
            token_pattern=r'(?u)\b[a-zA-Z_][a-zA-Z0-9_]*\b',
            max_features=self.config.get('max_features', 1000)
        )

    def process_repository(self, document_paths: list) -> Tuple[csr_matrix, np.ndarray, List[str], Dict]:

        if not isinstance(document_paths, list) or not document_paths:
            raise ValueError(f"document_paths does not exist: {document_paths}")
        
        docs_to_transform, files, structures = self.processor.process_files(document_paths)
        if not docs_to_transform:
            raise ValueError("No valid documents found in repository")
            
        doc_term_matrix = self.vectorizer.fit_transform(docs_to_transform)
        terms = self.vectorizer.get_feature_names_out()
        return doc_term_matrix, terms, files, structures