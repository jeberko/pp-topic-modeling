from pathlib import Path
from typing import List, Dict, Tuple, Set, Optional
from dataclasses import dataclass
import re
import logging
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache

@dataclass
class ProcessedFile:
   content: str
   structure: Dict[str, List[str]]
   path: Path

class CodeProcessor:
   CPP_KEYWORDS = frozenset({
       'int', 'double', 'float', 'char', 'void', 'bool', 'long', 'short',
       'class', 'struct', 'template', 'typename', 'public', 'private', 
       'protected', 'const', 'static', 'virtual', 'return', 'if', 'else', 
       'for', 'while', 'std', 'string', 'vector', 'auto', 'true', 'false', 
       'nullptr', 'this', 'new', 'delete', 'try', 'catch', 'throw', 
       'namespace', 'using', 'typedef'
   })

   def __init__(self, max_workers: Optional[int] = None):
       self.max_workers = max_workers
       self.logger = logging.getLogger(__name__)

   def process_files(self, doc_paths: list) -> Tuple[List[str], List[str], Dict[str, Dict[str, List[str]]]]:
       """Process all files in the repository concurrently."""
       if not isinstance(doc_paths, list) or not doc_paths:
           raise ValueError(f"Repository document paths do not exist")

       documents, file_paths, structures = [], [], {}
       
       with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
           futures = [
               executor.submit(self._process_single_file, file_path)
               for file_path in doc_paths
           ]

           for future in futures:
               try:
                   result = future.result()
                   if result:
                       documents.append(result.content)
                       file_paths.append(str(result.path))
                       structures[str(result.path)] = result.structure
               except Exception as e:
                   self.logger.error(f"Error processing file: {e}")

       if not documents:
           self.logger.warning(f"No valid documents found in {doc_paths}")

       return documents, file_paths, structures

   def _process_single_file(self, file_path: Path) -> Optional[ProcessedFile]:
       """Process a single source file."""
       try:
           with open(file_path, 'r', encoding='utf-8') as f:
               content = f.read()
           cleaned_content = self._clean_code(content)
           structure = self._analyze_structure(content)
           return ProcessedFile(
               content=cleaned_content,
               structure=structure,
               path=file_path
           )
       except UnicodeDecodeError:
           self.logger.error(f"Unicode decode error in {file_path}")
           return None
       except Exception as e:
           self.logger.error(f"Error processing {file_path}: {e}")
           return None

   @lru_cache(maxsize=10000)
   def _clean_code(self, content: str) -> str:
       """Clean and normalize code content."""
       # Remove comments
       content = re.sub(r'//.*?\n|/\*.*?\*/', '', content, flags=re.DOTALL)
       
       # Remove preprocessor directives
       content = re.sub(r'#include.*?\n|#define.*?\n', '', content)
       
       # Remove string literals
       content = re.sub(r'".*?"', '', content)
       
       # Remove numbers but keep identifiers with numbers
       content = re.sub(r'\b\d+\b', '', content)
       
       # Process words
       words = content.split()
       words = [w for w in words if w.lower() not in self.CPP_KEYWORDS]
       
       # Split camelCase and PascalCase
       processed_words = []
       for word in words:
           splits = re.findall(
               r'[A-Z][a-z]*|[a-z]+|[A-Z]{2,}(?=[A-Z][a-z]|\d|\W|$)|\d+', 
               word
           )
           processed_words.extend(splits)
       
       return ' '.join(processed_words).lower()

   @staticmethod
   def _analyze_structure(content: str) -> Dict[str, List[str]]:
       """Analyze code structure and return its components."""
       return {
           'classes': re.findall(r'class\s+(\w+)', content),
           'functions': re.findall(r'(?:void|int|double|bool)\s+(\w+)\s*\(', content),
           'includes': re.findall(r'#include\s*[<"]([^>"]+)[>"]', content),
           'imports': re.findall(r'(?:from|import)\s+([\w.]+)', content),
           'decorators': re.findall(r'@(\w+)', content)
       }