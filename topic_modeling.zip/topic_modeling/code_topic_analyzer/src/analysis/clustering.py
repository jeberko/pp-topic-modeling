from dataclasses import dataclass
from typing import Dict, List
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics.pairwise import cosine_similarity

@dataclass
class ClusteringConfig:
    n_clusters: int

class TermClusterer:
    def __init__(self, config: ClusteringConfig):
        self.config = config

    def cluster_terms(self, term_matrix: csr_matrix, feature_names: List[str]) -> Dict[int, List[str]]:
        """Cluster related terms based on co-occurrence."""
        similarity_matrix = cosine_similarity(term_matrix.T)
        clustering = AgglomerativeClustering(n_clusters=self.config.get('n_clusters',5))
        clusters = clustering.fit_predict(similarity_matrix)
        
        term_clusters = {}
        for term, cluster in zip(feature_names, clusters):
            if cluster not in term_clusters:
                term_clusters[cluster] = []
            term_clusters[cluster].append(term)
        
        return term_clusters