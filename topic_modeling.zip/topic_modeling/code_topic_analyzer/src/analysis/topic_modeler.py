from dataclasses import dataclass
from typing import Tuple, List
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.decomposition import LatentDirichletAllocation

@dataclass
class TopicModelingConfig:
    n_components: int
    random_state: int
    n_jobs: int = -1
    learning_method: str = 'batch'
    max_iter: int = 50
    doc_topic_prior: float = 0.1
    topic_word_prior: float = 0.01

class TopicModeler:
    def __init__(self, config: TopicModelingConfig):
        self.config = config
        self.model = self._initialize_model()

    def _initialize_model(self) -> LatentDirichletAllocation:
        print("topic modeler config")
        print(self.config)
        return LatentDirichletAllocation(
            n_components=self.config.get('n_components', None),
            random_state=self.config.get('random_state', None),
            n_jobs=self.config.get('n_jobs', None),
            learning_method=self.config.get('learning_method', 'batch'),
            max_iter=self.config.get('max_iter', 10),
            doc_topic_prior=self.config.get('doc_topic_prior', None),
            topic_word_prior=self.config.get('topic_word_prior', None)
        )

    def create_model(self, doc_term_matrix: csr_matrix) -> Tuple[LatentDirichletAllocation, np.ndarray]:
        """Create and train the topic model."""
        doc_topics = self.model.fit_transform(doc_term_matrix)
        return self.model, doc_topics

    def get_top_terms(self, feature_names: List[str], n_top_words: int = 10) -> List[List[Tuple[str, float]]]:
        """Get top terms for each topic."""
        topics = []
        for topic in self.model.components_:
            top_idx = topic.argsort()[:-n_top_words-1:-1]
            top_terms = [(feature_names[i], topic[i]) for i in top_idx]
            topics.append(top_terms)
        return topics