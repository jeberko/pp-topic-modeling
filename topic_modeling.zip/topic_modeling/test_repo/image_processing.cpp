// File: image_processing.cpp
/*
 * This file implements basic image processing operations
 * including filters, color conversions, and basic transformations
 */

#include <vector>
#include <string>
#include <iostream>
#include <memory>
#include <cmath>

namespace imaging {

class ColorConverter {
public:
    // Convert RGB to grayscale using luminance method
    static double rgbToGrayscale(int red, int green, int blue) {
        return 0.299 * red + 0.587 * green + 0.114 * blue;
    }
};

class ImageFilter {
private:
    std::vector<std::vector<double>> kernel;
    int kernelSize;

public:
    ImageFilter(int size) : kernelSize(size) {
        // Initialize Gaussian blur kernel
        kernel.resize(size, std::vector<double>(size));
        createGaussianKernel();
    }

    void createGaussianKernel(double sigma = 1.0) {
        double sum = 0.0;
        int center = kernelSize / 2;

        // Generate 2D Gaussian kernel
        for (int x = 0; x < kernelSize; x++) {
            for (int y = 0; y < kernelSize; y++) {
                double xDist = x - center;
                double yDist = y - center;
                kernel[x][y] = exp(-(xDist * xDist + yDist * yDist) / (2 * sigma * sigma));
                sum += kernel[x][y];
            }
        }

        // Normalize kernel
        for (auto& row : kernel) {
            for (double& value : row) {
                value /= sum;
            }
        }
    }
};

class ImageProcessor {
private:
    std::vector<std::vector<int>> imageData;
    int width;
    int height;

public:
    ImageProcessor(int w, int h) : width(w), height(h) {
        imageData.resize(height, std::vector<int>(width));
    }

    // Apply various image transformations
    void rotate90Degrees() {
        std::vector<std::vector<int>> rotated(width, std::vector<int>(height));
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                rotated[j][height - 1 - i] = imageData[i][j];
            }
        }
        std::swap(width, height);
        imageData = std::move(rotated);
    }

    void flipHorizontal() {
        for (auto& row : imageData) {
            for (int i = 0; i < width / 2; i++) {
                std::swap(row[i], row[width - 1 - i]);
            }
        }
    }

    // Basic image enhancement operations
    void adjustBrightness(double factor) {
        for (auto& row : imageData) {
            for (int& pixel : row) {
                pixel = std::min(255, static_cast<int>(pixel * factor));
            }
        }
    }

    void applyThreshold(int threshold) {
        for (auto& row : imageData) {
            for (int& pixel : row) {
                pixel = (pixel > threshold) ? 255 : 0;
            }
        }
    }
};

class ImageCompressor {
public:
    // Simple RLE (Run-Length Encoding) compression
    std::vector<std::pair<int, int>> compress(const std::vector<int>& data) {
        std::vector<std::pair<int, int>> compressed;
        if (data.empty()) return compressed;

        int count = 1;
        int current = data[0];

        for (size_t i = 1; i < data.size(); i++) {
            if (data[i] == current) {
                count++;
            } else {
                compressed.push_back({current, count});
                current = data[i];
                count = 1;
            }
        }
        compressed.push_back({current, count});
        return compressed;
    }
};

} // namespace imaging

// Example usage
int main() {
    // Create and use image processing objects
    imaging::ImageProcessor processor(800, 600);
    processor.adjustBrightness(1.2);
    processor.applyThreshold(128);
    processor.rotate90Degrees();

    imaging::ImageFilter filter(3);
    imaging::ImageCompressor compressor;

    std::cout << "Image processing operations completed." << std::endl;
    return 0;
}